package com.convertors.JSONXMLConvertors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.BooleanNode;
import com.fasterxml.jackson.databind.node.NullNode;
import com.fasterxml.jackson.databind.node.NumericNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

public class ConverterFactory {
	private static ConverterFactory instance;
	
	public  static ConverterFactory getInstance(){
		if(null==instance){
			return new ConverterFactory();
		}
		return instance;
	}

	public XMLJSONConvertorI createXMLJSONConverter(final JsonNode node){
		if(node instanceof ObjectNode){
			return  new XmlJsonObjectConverter();
		}else if(node instanceof ArrayNode){
			return  new XmlJsonArrayConverter();
		}else if(node instanceof TextNode){
			return  new XmlJsonTextConverter();
		}else if(node instanceof NumericNode){
			return  new XmlJsonNumericConverter();
		}else if(node instanceof NullNode){
			return  new XmlJsonNullConverter();
		}else if(node instanceof BooleanNode){
			return  new XmlJsonBooleanConverter();
		}
		
		return (XMLJSONConvertorI) new XmlJsonArrayConverter();
		
	}

}
