package com.convertors.JSONXMLConvertors;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.fasterxml.jackson.databind.JsonNode;

public interface XMLJSONConvertorI {
public void convertJSONtoXML(final JsonNode jsonNode,final Document document);
public String getKey();
public void setKey(final String key);
public Element getParent();
public void setParent(Element parent);
}
