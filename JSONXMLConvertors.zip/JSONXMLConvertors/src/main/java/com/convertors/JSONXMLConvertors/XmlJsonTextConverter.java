package com.convertors.JSONXMLConvertors;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.fasterxml.jackson.databind.JsonNode;

public class XmlJsonTextConverter implements XMLJSONConvertorI{
	String key="";
	Element parent=null;

	public void convertJSONtoXML(JsonNode jsonNode, Document document) {
		ElementCreatorUtil.getInstance().createElement(jsonNode,document, getKey(),"string",parent);
		
	}

	public void setKey(String key) {
		this.key=key;
		
	}
	
	public String getKey() {
		return this.key;
	}
	
	public Element getParent() {
		return parent;
	}
	public void setParent(Element parent) {
		this.parent = parent;
	}

}
