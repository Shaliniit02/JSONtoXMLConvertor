package com.convertors.JSONXMLConvertors;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/*In the command line give inputs as per below order
 *1.input json file location
 *2. output xml file location 
 * C:\Users\pshalin1\Desktop\Testing\test.json
*C:\Users\pshalin1\Desktop\Testing\output.xml*/


public class Convertor {
	public static void main(String args[]){
		System.out.println("Enter the location of json file (e.g. C:\\Users\\pshalin1\\Desktop\\Testing\\test.json): ");
		Scanner scan = new Scanner(System.in);
		final String jsonFilePath=scan.nextLine();
	    System.out.println("Enter the location of xml file(e.g. C:\\Users\\pshalin1\\Desktop\\Testing\\output.xml): ");
		final String xmlFilePath=scan.nextLine();
		FileReader reader;
		try {
			reader = new FileReader(jsonFilePath);		
			JsonFactory factory=new JsonFactory();
			ObjectMapper mapper=new ObjectMapper(factory);
			JsonNode rootNode=mapper.readTree(reader);

			DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();		    
			DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder(); 
			Document document = documentBuilder.newDocument();
			
			XMLJSONConvertorI xmlJsonConvertor=ConverterFactory.getInstance().createXMLJSONConverter(rootNode);
			xmlJsonConvertor.convertJSONtoXML(rootNode, document);
			
			 TransformerFactory transformerFactory = TransformerFactory.newInstance();
	            Transformer transformer = transformerFactory.newTransformer();
	            DOMSource domSource = new DOMSource(document);
	            File outputFile=new File(xmlFilePath);
	            if(!outputFile.exists()){
	            	outputFile.createNewFile();
	            }
	            StreamResult streamResult = new StreamResult(outputFile); 
	            transformer.transform(domSource, streamResult);
	 
	            System.out.println("Done creating XML File");
			reader.close();
		} catch (JsonParseException e) {
			System.out.println("Error in parsing json. Not a valid json file");
			
		} catch (FileNotFoundException e) {
			System.out.println("Please Enter valid File Name. The Json file does not exist.");
			
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{

		}



	}
}
