package com.convertors.JSONXMLConvertors;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.fasterxml.jackson.databind.JsonNode;

public class ElementCreatorUtil {
private static ElementCreatorUtil instance;
	
	public  static ElementCreatorUtil getInstance(){
		if(null==instance){
			return new ElementCreatorUtil();
		}
		return instance;
	}
	
	public void createAttribute(final Element element,final Document document,final String key){
		if(!"".equals(key)){
		Attr attr = document.createAttribute("name");
        attr.setValue(key);
        element.setAttributeNode(attr);
		}
	}
	
	public Element createElement(JsonNode jsonNode,final Document document,final String key,final String elementName,final Element parent){
		Element element=document.createElement(elementName);
		createAttribute(element, document, key);
		if(!"null".equals(elementName)){
		element.appendChild(document.createTextNode(jsonNode.asText()));
		}
		if(null==parent){
			document.appendChild(element);
		}else{
			parent.appendChild(element);
		}
		return element;
	}
}
