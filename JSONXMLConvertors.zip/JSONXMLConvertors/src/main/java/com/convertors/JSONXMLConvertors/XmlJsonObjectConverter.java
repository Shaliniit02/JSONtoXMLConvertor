package com.convertors.JSONXMLConvertors;

import java.util.Iterator;
import java.util.Map;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.fasterxml.jackson.databind.JsonNode;

public class XmlJsonObjectConverter implements XMLJSONConvertorI{
	String key="";
	Element parent=null;
	
	public void convertJSONtoXML(JsonNode jsonNode, Document document) {
		Element element=ElementCreatorUtil.getInstance().createElement(jsonNode, document, getKey(),"object",parent);		
		Iterator<Map.Entry<String,JsonNode>> fieldsIterator = jsonNode.fields();
		while (fieldsIterator.hasNext()) {
			Map.Entry<String,JsonNode> field = fieldsIterator.next();
			XMLJSONConvertorI xmlJsonConvertor=ConverterFactory.getInstance().createXMLJSONConverter(field.getValue());
			xmlJsonConvertor.setKey(field.getKey());
			xmlJsonConvertor.setParent(element);
			xmlJsonConvertor.convertJSONtoXML(field.getValue(), document);
		}		
	}
	
	public String getKey() {
		return this.key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Element getParent() {
		return parent;
	}
	public void setParent(Element parent) {
		this.parent = parent;
	}

}
